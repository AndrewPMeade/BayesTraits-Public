#ifndef BTOCL_RUNTIME_KERNELS_H
#define BTOCL_RUNTIME_KERNELS_H

#ifdef BTOCL

#include "btocl_runtime.h"

// added to get access to TREES and OPT
//#include "typedef.h"



// ********* end kernel indexes ************



#endif // if BTOCL defined

#endif

