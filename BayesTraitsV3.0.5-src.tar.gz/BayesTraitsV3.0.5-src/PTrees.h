#ifndef PTREES_H
#define PTREES_H

#include "TypeDef.h"

void	SetTreePNodes(TREES *Trees);
void	SetPTrees(OPTIONS *Opt, TREES *Trees);


#endif