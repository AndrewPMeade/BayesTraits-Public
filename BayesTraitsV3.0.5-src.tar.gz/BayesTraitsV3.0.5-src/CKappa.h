#ifndef CKAPPA_HEADDER
#define CKAPPA_HEADDER

void	MakeKappaV(TREES* Trees, TREE *Tree, double Kappa);

#endif

