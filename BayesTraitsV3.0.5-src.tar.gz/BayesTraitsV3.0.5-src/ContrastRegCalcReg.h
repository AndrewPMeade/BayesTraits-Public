#ifndef CON_REG_CALC_REG_H
#define CON_REG_CALC_REG_H

#include "Matrix.h"
#include "TypeDef.h"

double*	ContrastMultiReg(MATRIX *M, int TestCorrel);

#endif