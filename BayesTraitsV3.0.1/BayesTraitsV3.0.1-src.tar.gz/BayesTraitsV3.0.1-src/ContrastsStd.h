#ifndef CONTRASTOLDH
#define CONTRASTOLDH

#include "TypeDef.h"

double	CaclStdContrastLh(OPTIONS *Opt, TREES *Trees, RATES *Rates);
		
double	CaclStdContrastLhML(OPTIONS *Opt, TREES *Trees, RATES *Rates);

#endif
