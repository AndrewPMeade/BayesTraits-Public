#ifndef PROB_H
#define PROB_H

double		PDFSGamma(double x, double Alpha, double Beta);


#endif