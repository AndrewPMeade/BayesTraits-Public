#ifndef THREADED_HEADDER
#define THREADED_HEADDER

int		GetThreadNo(void);
int		GetMaxThreads(void);
void	SetNoOfThreads(int No);
double	GetSeconds(void);

#endif
