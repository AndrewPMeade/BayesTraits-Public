#ifndef FOSSIL_H
#define FOSSIL_H

#include "TypeDef.h"

void SetFossils(TREES *Trees, OPTIONS *Opt);

#endif