extern int      DiscreteGamma (double *freqK, double *rK, double alfa, double beta, int K, int median);
extern int      AutodGamma (double **M, double *freqK, double *rK, double *rho1, double alfa, double rho, int K);
extern double   IncompleteGamma (double x, double alpha, double LnGamma_alpha);
extern double   LnGamma (double alpha);
