#ifndef SIMDATA_H
#define SIMDATA_H

#include "TypeDef.h"
#include "Trees.h"

void	SimData(OPTIONS *Opt, TREES *Trees, RATES *Rates);

#endif