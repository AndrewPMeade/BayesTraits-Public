#ifndef BATCHMODE_H
#define BATCHMODE_H


void	BatchRun(char *BatchFN);

#endif